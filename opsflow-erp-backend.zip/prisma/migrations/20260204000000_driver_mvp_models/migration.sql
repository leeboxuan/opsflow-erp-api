-- No-op: migration record restored for history (schema in 20260203201911_driver_mvp_models).
DO $$ BEGIN NULL; END $$;
